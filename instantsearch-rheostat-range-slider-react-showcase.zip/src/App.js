import React, { Component } from "react";
import RheostatRangeSlider from "instantsearch-rheostat-range-slider-react";
import {
  InstantSearch,
  SearchBox,
  Pagination,
  Configure,
  Panel
} from "react-instantsearch-dom";
import "./App.css";
import Stats from "./Stats.js";
import Content from "./Content";

class App extends Component {
  render() {
    return (
      <InstantSearch
        appId="B1G2GM9NG0"
        apiKey="aadef574be1f9252bb48d4ea09b5cfe5"
        indexName="demo_ecommerce"
      >
        <main className="search-container">
          <Configure
            hitsPerPage={5}
            attributesToSnippet={["description:24"]}
            snippetEllipsisText=" [...]"
          />
          <div className="right-panel">
            <div id="hits">
              <Content />
            </div>
            <div id="searchbox">
              <SearchBox
                translations={{ placeholder: "Search for products" }}
              />
            </div>
            <div id="stats">
              <Stats />
            </div>
            <div id="pagination">
              <Pagination />
            </div>
          </div>
          <div className="left-panel">
            <div id="price">
              <Panel header="Price">
                <RheostatRangeSlider attribute="price" />
              </Panel>
            </div>
          </div>
        </main>
      </InstantSearch>
    );
  }
}

export default App;
